"""
Moon Leaks Video Sharing Bot
"""

import json
import os
import random
from typing import Dict, List, Any

from telegram import (
    ReplyKeyboardMarkup,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

# Bot token
BOT_TOKEN = "8349861272:AAFf7R0UFD7QU5LPAdgz_VbcDaKplLGxwiw"

# Owner / Super Admin user id
OWNER_ID = 6847499628

# Channels list (force join)
REQUIRED_CHANNELS = [
    {
        "id": -1002699957030,
        "name": "𝙈.𝙊.𝙊.𝙉 𝙒𝙊𝙍𝙇𝘿 🔥",
        "link": "https://t.me/EscrowMoon",
    },
    {
        "id": -1002148399900,
        "name": "MiddleAppect",
        "link": "https://t.me/MiddleAppect",
    },
    {
        "id": -1002277863913,
        "name": "About LuffyBots 💀",
        "link": "https://t.me/AboutLuffyBots",
    },
    {
        "id": -1002588749986,
        "name": "Channel 4",
        "link": "https://t.me/+yZVVK3L_IGdjYzQ9",
    },
]

# /start / verification ke liye photo file_id
START_PHOTO_ID = (
    "AgACAgUAAxkBAANGaSF-MCIW2hCVrsrf2Aba8-x07PoAAkoNaxuFIwlVfZt7lOWQcKEBAAMCAAN5AAM2BA"
)

# Data file
DATA_FILE = "data.json"


# ---------------------------------------------------------------------------
# DATA HELPERS
# ---------------------------------------------------------------------------

def _empty_data() -> Dict[str, Any]:
    """Fresh data structure."""
    data: Dict[str, Any] = {f"room{i}": [] for i in range(1, 5)}
    data["users"] = {}           # { user_id(str): {"verified": bool} }
    data["last_sent"] = {}       # { "room1": last_file_id, ... }
    data["admins"] = []          # extra admins (string user_ids)
    data["upload_sessions"] = {} # { user_id(str): room_number(int) }
    return data


def load_data() -> Dict[str, Any]:
    """Load data from file or create default.

    Purana data.json ho to wahi use karega, sirf missing ho to new banega.
    """
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            data = _empty_data()
    else:
        data = _empty_data()

    # Ensure required keys
    for i in range(1, 5):
        data.setdefault(f"room{i}", [])
    data.setdefault("users", {})
    data.setdefault("last_sent", {})
    data.setdefault("admins", [])
    data.setdefault("upload_sessions", {})
    return data


def save_data(data: Dict[str, Any]) -> None:
    """Save data to file (rooms, users, admins, sessions)."""
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def update_user_status(user_id: int, verified: bool) -> None:
    """Store/Update user verified flag."""
    data = load_data()
    users = data.setdefault("users", {})
    uid = str(user_id)
    record = users.get(uid, {"verified": False})

    if verified:
        record["verified"] = True
    else:
        if uid not in users:
            record["verified"] = False

    users[uid] = record
    save_data(data)


# ---------------------------------------------------------------------------
# OWNER / ADMIN UTILS
# ---------------------------------------------------------------------------

def is_owner(user_id: int) -> bool:
    return user_id == OWNER_ID


def is_admin(user_id: int) -> bool:
    """Owner + stored admins."""
    if is_owner(user_id):
        return True
    data = load_data()
    admins = data.get("admins", [])
    return str(user_id) in admins


# ---------------------------------------------------------------------------
# MEMBERSHIP & JOIN INSTRUCTIONS
# ---------------------------------------------------------------------------

async def check_membership(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Return True if user in all required channels."""
    for channel in REQUIRED_CHANNELS:
        try:
            member = await context.bot.get_chat_member(
                chat_id=channel["id"],
                user_id=user_id,
            )
            if getattr(member, "status", None) in {"left", "kicked"}:
                return False
        except Exception:
            return False
    return True


async def send_join_instructions_inline(update: Update) -> None:
    """
    User ne saare channels join nahi kiye:
    - Photo + caption
    - Neeche inline channel buttons + ✅ Verify
    """
    buttons = [
        [InlineKeyboardButton(text=channel["name"], url=channel["link"])]
        for channel in REQUIRED_CHANNELS
    ]
    buttons.append(
        [InlineKeyboardButton(text="✅ Verify", callback_data="verify")]
    )
    keyboard = InlineKeyboardMarkup(buttons)

    caption = (
        "<b>Must join all channels to get videos.</b>\n"
        "Neeche wale buttons se saare channels join karo, phir ✅ Verify dabao."
    )

    await update.effective_message.reply_photo(
        photo=START_PHOTO_ID,
        caption=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard,
    )


# ---------------------------------------------------------------------------
# COMMANDS
# ---------------------------------------------------------------------------

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start."""
    user_id = update.effective_user.id

    # membership check
    if not await check_membership(user_id, context):
        update_user_status(user_id, verified=False)
        await send_join_instructions_inline(update)
        return

    # verified user
    update_user_status(user_id, verified=True)

    # welcome photo
    await update.message.reply_photo(photo=START_PHOTO_ID)

    description = (
        "<b>Welcome to the Moon Leaks Bot 🌝</b>\n"
        "Neeche kisi bhi room ko select karo, random video milega."
    )
    keyboard = ReplyKeyboardMarkup(
        [["Room 1", "Room 2"], ["Room 3", "Room 4"]],
        resize_keyboard=True,
        one_time_keyboard=False,
    )

    await update.message.reply_text(
        description,
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard,
    )


async def upload_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    /upload command (admin only).

    Modes:
    - /upload 1  -> easy upload mode for Room 1 (auto-save next videos)
    - /upload stop  -> stop easy upload mode
    - /upload <file_id> <room_number> -> direct add
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Only admins can use this command.")
        return

    if not context.args:
        await update.message.reply_text(
            "Usage:\n"
            "/upload 1  -> Easy upload mode for Room 1 (1-4)\n"
            "/upload stop  -> Stop easy upload mode\n"
            "/upload <file_id> <room>  -> Direct add"
        )
        return

    # stop/cancel upload session
    if context.args[0].lower() in {"stop", "cancel", "off"}:
        data = load_data()
        sessions = data.setdefault("upload_sessions", {})
        uid = str(user_id)
        if uid in sessions:
            sessions.pop(uid, None)
            save_data(data)
            await update.message.reply_text("Easy upload mode stopped for you.")
        else:
            await update.message.reply_text("Aapke liye koi active upload mode nahi hai.")
        return

    # easy upload: Only room number diya gaya
    if len(context.args) == 1:
        try:
            room_number = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Room number must be 1, 2, 3, or 4.")
            return
        if room_number not in {1, 2, 3, 4}:
            await update.message.reply_text("Room number must be between 1 and 4.")
            return

        data = load_data()
        sessions = data.setdefault("upload_sessions", {})
        sessions[str(user_id)] = room_number
        save_data(data)

        await update.message.reply_text(
            f"Easy upload mode ON for Room {room_number} ✅\n\n"
            "Ab jitne videos aap bhejoge, sab Room "
            f"{room_number} me automatically add ho jayenge.\n"
            "Jab kaam ho jaye to /upload stop bhej dena."
        )
        return

    # legacy mode: /upload <file_id> <room_number>
    if len(context.args) >= 2:
        file_id = context.args[0]
        try:
            room_number = int(context.args[1])
        except ValueError:
            await update.message.reply_text("Room number must be between 1 and 4.")
            return
        if room_number not in {1, 2, 3, 4}:
            await update.message.reply_text("Room number must be between 1 and 4.")
            return

        data = load_data()
        key = f"room{room_number}"
        data.setdefault(key, [])
        data[key].append(file_id)
        save_data(data)

        await update.message.reply_text(
            f"Added file to Room {room_number}. Total videos in this room: {len(data[key])}"
        )
        return


async def reset_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /reset (admin only)."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Only admins can reset the bot.")
        return

    data = _empty_data()
    save_data(data)
    await update.message.reply_text("Bot has been reset. All rooms are now empty.")


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /stats (admin only)."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Only admins can view stats.")
        return

    data = load_data()
    users = data.get("users", {})
    total = len(users)
    verified = sum(1 for rec in users.values() if rec.get("verified"))
    not_verified = total - verified

    text = (
        "<b>📊 Bot Stats</b>\n"
        f"👥 Total Users: <b>{total}</b>\n"
        f"✅ Verified Users: <b>{verified}</b>\n"
        f"⚠️ Not Verified Users: <b>{not_verified}</b>"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def totalvids_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /totalvids – room-wise video count (admin only)."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Only admins can use this command.")
        return

    data = load_data()

    text = (
        "<b>📁 Total Videos in Rooms</b>\n\n"
        f"Room 1: <b>{len(data.get('room1', []))}</b>\n"
        f"Room 2: <b>{len(data.get('room2', []))}</b>\n"
        f"Room 3: <b>{len(data.get('room3', []))}</b>\n"
        f"Room 4: <b>{len(data.get('room4', []))}</b>"
    )

    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Broadcast (admin only):
    - Reply me photo/video ho -> wahi media + caption sabko
    - Warna /broadcast <text> -> text broadcast
    """
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("Only admins can use this command.")
        return

    data = load_data()
    users = data.get("users", {})

    reply = update.message.reply_to_message

    sent = 0
    failed = 0

    # Media broadcast (reply to photo/video/document/etc.)
    if reply and (reply.photo or reply.video or reply.document or reply.animation):
        for uid in users.keys():
            try:
                await context.bot.copy_message(
                    chat_id=int(uid),
                    from_chat_id=reply.chat_id,
                    message_id=reply.message_id,
                )
                sent += 1
            except Exception:
                failed += 1
        await update.message.reply_text(
            f"📢 Media broadcast completed!\n\n✔ Sent: {sent}\n❌ Failed: {failed}"
        )
        return

    # Text broadcast
    if not context.args:
        await update.message.reply_text(
            "Usage: /broadcast <message>\n"
            "Ya phir kisi photo/video ke reply me /broadcast bhejo."
        )
        return

    message = " ".join(context.args)

    for uid in users.keys():
        try:
            await context.bot.send_message(chat_id=int(uid), text=message)
            sent += 1
        except Exception:
            failed += 1

    await update.message.reply_text(
        f"📢 Broadcast completed!\n\n✔ Sent: {sent}\n❌ Failed: {failed}"
    )


async def cmds_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show all admin commands (admin only)."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Only admins can use this command.")
        return

    text = (
        "<b>🛠 Admin Commands</b>\n\n"
        "/upload 1..4 - Easy upload mode (auto-save all videos to that room)\n"
        "/upload stop - Stop easy upload mode\n"
        "/upload &lt;file_id&gt; &lt;room&gt; - Direct add video\n"
        "/reset - Clear all rooms data\n"
        "/stats - Show users stats\n"
        "/totalvids - Show total videos per room\n"
        "/broadcast &lt;text&gt; - Send text to all users\n"
        "/broadcast (reply to media) - Send photo/video + caption to all users\n"
        "/addadmin - Add new admin (owner only)\n"
        "/removeadmin - Remove admin (owner only)\n"
        "/cmds - Show this admin commands list\n"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def addadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Add admin (OWNER only). /addadmin <user_id> or reply to user."""
    user_id = update.effective_user.id
    if not is_owner(user_id):
        await update.message.reply_text("Only the owner can manage admins.")
        return

    target_id = None

    if context.args:
        try:
            target_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("User id must be a number.")
            return
    elif update.message.reply_to_message:
        target_id = update.message.reply_to_message.from_user.id

    if target_id is None:
        await update.message.reply_text(
            "Usage: /addadmin <user_id>\n"
            "Ya phir kisi user ke message pe reply karke /addadmin bhejo."
        )
        return

    if is_owner(target_id):
        await update.message.reply_text("Owner already has all permissions.")
        return

    data = load_data()
    admins = data.setdefault("admins", [])
    uid = str(target_id)

    if uid in admins:
        await update.message.reply_text("Ye user already admin hai.")
        return

    admins.append(uid)
    save_data(data)

    await update.message.reply_text(f"Added admin: <code>{uid}</code>", parse_mode=ParseMode.HTML)


async def removeadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Remove admin (OWNER only). /removeadmin <user_id> or reply."""
    user_id = update.effective_user.id
    if not is_owner(user_id):
        await update.message.reply_text("Only the owner can manage admins.")
        return

    target_id = None

    if context.args:
        try:
            target_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("User id must be a number.")
            return
    elif update.message.reply_to_message:
        target_id = update.message.reply_to_message.from_user.id

    if target_id is None:
        await update.message.reply_text(
            "Usage: /removeadmin <user_id>\n"
            "Ya phir kisi admin ke message pe reply karke /removeadmin bhejo."
        )
        return

    if is_owner(target_id):
        await update.message.reply_text("Owner ko remove nahi kar sakte.")
        return

    data = load_data()
    admins = data.setdefault("admins", [])
    uid = str(target_id)

    if uid not in admins:
        await update.message.reply_text("Ye user admin list me nahi hai.")
        return

    admins.remove(uid)
    save_data(data)

    await update.message.reply_text(f"Removed admin: <code>{uid}</code>", parse_mode=ParseMode.HTML)


# ---------------------------------------------------------------------------
# ROOM SELECTION (USER KE LIYE) – ONLY VIDEO, NO FILE ID
# ---------------------------------------------------------------------------

async def handle_room_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text buttons: Room 1/2/3/4 (user ko sirf video mile)."""
    message_text = (update.message.text or "").strip()
    valid_rooms = {
        "Room 1": "room1",
        "Room 2": "room2",
        "Room 3": "room3",
        "Room 4": "room4",
    }

    if message_text not in valid_rooms:
        return

    user_id = update.effective_user.id

    # Check membership again
    if not await check_membership(user_id, context):
        update_user_status(user_id, verified=False)
        await send_join_instructions_inline(update)
        return

    update_user_status(user_id, verified=True)

    data = load_data()
    room_key = valid_rooms[message_text]
    videos: List[str] = data.get(room_key, [])

    if not videos:
        await update.message.reply_text("No videos in this room yet. Please check back later.")
        return

    # avoid same video twice in a row
    last_sent = data.setdefault("last_sent", {})
    last_file = last_sent.get(room_key)

    if len(videos) == 1:
        file_id = videos[0]
    else:
        candidates = [v for v in videos if v != last_file] or videos
        file_id = random.choice(candidates)

    last_sent[room_key] = file_id
    save_data(data)

    # sirf video/doccument send karo – koi File ID message nahi
    try:
        await update.message.reply_video(file_id)
    except Exception:
        try:
            await update.message.reply_document(file_id)
        except Exception:
            await update.message.reply_text("Failed to send the video. File ID may be invalid.")


# ---------------------------------------------------------------------------
# MEDIA FROM ADMINS – FILE ID + EASY UPLOAD
# ---------------------------------------------------------------------------

async def handle_media_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Admin sends media:
    - Humesha file_id mono font me reply (copy code style)
    - Agar easy upload mode ON hai -> us room me automatic save bhi
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        return

    message = update.message
    file_id = None

    if message.video:
        file_id = message.video.file_id
    elif message.photo:
        file_id = message.photo[-1].file_id  # highest resolution

    if not file_id:
        return

    # EASY UPLOAD: check session
    data = load_data()
    sessions = data.setdefault("upload_sessions", {})
    uid = str(user_id)
    room_number = sessions.get(uid)

    if room_number in {1, 2, 3, 4}:
        room_key = f"room{room_number}"
        room_list: List[str] = data.setdefault(room_key, [])
        room_list.append(file_id)
        save_data(data)
        info_text = (
            f"Saved to Room {room_number}. "
            f"Total videos: {len(room_list)}"
        )
    else:
        info_text = "Not in easy upload mode. Use /upload 1-4 to enable."

    # File ID mono font + info line
    text = "<b>File ID:</b>\n<pre>{}</pre>\n\n{}".format(file_id, info_text)
    await message.reply_text(text, parse_mode=ParseMode.HTML)


# ---------------------------------------------------------------------------
# VERIFY CALLBACK
# ---------------------------------------------------------------------------

async def verify_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Inline ✅ Verify button callback."""
    query = update.callback_query
    user_id = query.from_user.id
    await query.answer()

    if await check_membership(user_id, context):
        update_user_status(user_id, verified=True)

        description = (
            "<b>Verification successful ✅</b>\n"
            "Ab neeche se koi bhi room choose karo, random video milega."
        )
        keyboard = ReplyKeyboardMarkup(
            [["Room 1", "Room 2"], ["Room 3", "Room 4"]],
            resize_keyboard=True,
            one_time_keyboard=False,
        )
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=description,
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )
    else:
        update_user_status(user_id, verified=False)
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text="You must join all channels before accessing videos.",
        )
        await send_join_instructions_inline(update)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main() -> None:
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    # Commands
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("upload", upload_command))
    application.add_handler(CommandHandler("reset", reset_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("totalvids", totalvids_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    application.add_handler(CommandHandler("cmds", cmds_command))
    application.add_handler(CommandHandler("addadmin", addadmin_command))
    application.add_handler(CommandHandler("removeadmin", removeadmin_command))

    # Media -> file_id for admins (and easy upload auto-save)
    application.add_handler(
        MessageHandler(filters.PHOTO | filters.VIDEO, handle_media_id)
    )

    # Room selection (any text that is not a command)
    application.add_handler(
        MessageHandler(filters.TEXT & (~filters.COMMAND), handle_room_selection)
    )

    # Verify callback
    application.add_handler(
        CallbackQueryHandler(verify_callback, pattern="^verify$")
    )

    application.run_polling()


if __name__ == "__main__":
    main()